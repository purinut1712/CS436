package bookorder;

/**
 *
 * @author user
 */
public class BookOrder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        dbconnect connect = new dbconnect();
        connect.connectDB();
        
        Main_Frame frame_1 = new Main_Frame();
        frame_1.setVisible(true);
    }
    
}
