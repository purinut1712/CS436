package bookorder;

/**
 *
 * @author user
 */
import java.sql.*;

public class dbconnect {
    Connection conn = null;
    
    public static Connection connectDB(){
        try{
            
            Class.forName("org.sqlite.JDBC");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:book_order.sqlite");
            
            System.out.println("Connection Successful");
            
            return conn;
            
        }catch(Exception e){
            System.err.println("Connection Failed :" + e);
            
            return null;
        }
        
    }
    
}
