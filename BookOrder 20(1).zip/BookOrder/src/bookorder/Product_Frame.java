package bookorder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import net.proteanit.sql.DbUtils;

public class Product_Frame extends javax.swing.JFrame {
    Connection conn;
    ResultSet rs;
    PreparedStatement pst;
    
    public Product_Frame() {
        initComponents();
        conn = dbconnect.connectDB();
        Product_Table();
    }

        public void Product_Table(){
        try{
            String sql = "select product_id as Product_ID, product_title as Title, product_author as Author, product_publisher as Publisher, product_publication_date as Publication_Date, product_price as Price, product_quantity as Quantity, product_description as Description  from Product";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            table_product.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Catch Error 1 :" + e);
        }finally{
            try{
                rs.close();
                pst.close();
            }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Catch Error 2  "+ e);
                }
            }
        }
        
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        btn_back = new javax.swing.JButton();
        tabbed_product = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        txt_add_id = new javax.swing.JTextField();
        txt_add_title = new javax.swing.JTextField();
        txt_add_author = new javax.swing.JTextField();
        txt_add_publisher = new javax.swing.JTextField();
        txt_add_publication_date = new javax.swing.JTextField();
        txt_add_price = new javax.swing.JTextField();
        txt_add_quantity = new javax.swing.JTextField();
        btn_add_product = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txt_add_descript = new javax.swing.JTextArea();
        btn_ctr_add_clear = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        txt_edit_id = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txt_edit_title = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        txt_edit_author = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        txt_edit_publisher = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        txt_edit_publication_date = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        txt_edit_price = new javax.swing.JTextField();
        txt_edit_quantity = new javax.swing.JTextField();
        btn_edit_search = new javax.swing.JButton();
        btn_edit_product = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txt_edit_descript = new javax.swing.JTextArea();
        btn_ctr_edit_clear = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_product = new javax.swing.JTable();
        btn_delete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PRODUCT");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(265, 265, 265))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        btn_back.setBackground(new java.awt.Color(242, 242, 242));
        btn_back.setText("Back");
        btn_back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_backMouseClicked(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel16.setText("Book ID");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel17.setText("Title");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel18.setText("Author(s)");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel19.setText("Publisher");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel20.setText("Description");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel21.setText("Price");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel22.setText("Quantity in Stock");

        txt_add_id.setBackground(new java.awt.Color(242, 242, 242));

        txt_add_title.setBackground(new java.awt.Color(242, 242, 242));

        txt_add_author.setBackground(new java.awt.Color(242, 242, 242));

        txt_add_publisher.setBackground(new java.awt.Color(242, 242, 242));

        txt_add_publication_date.setBackground(new java.awt.Color(242, 242, 242));

        txt_add_price.setBackground(new java.awt.Color(242, 242, 242));

        txt_add_quantity.setBackground(new java.awt.Color(242, 242, 242));

        btn_add_product.setBackground(new java.awt.Color(242, 242, 242));
        btn_add_product.setText("Add Product");
        btn_add_product.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_add_productMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel2.setText("Publication Date");

        txt_add_descript.setBackground(new java.awt.Color(242, 242, 242));
        txt_add_descript.setColumns(20);
        txt_add_descript.setRows(5);
        jScrollPane2.setViewportView(txt_add_descript);

        btn_ctr_add_clear.setBackground(new java.awt.Color(242, 242, 242));
        btn_ctr_add_clear.setText("Clear");
        btn_ctr_add_clear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_ctr_add_clearMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_ctr_add_clear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_add_product))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel16)
                            .addComponent(jLabel17)
                            .addComponent(jLabel18)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txt_add_title)
                                .addComponent(txt_add_id, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE))
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txt_add_publisher)
                                .addComponent(txt_add_author, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                                .addComponent(txt_add_publication_date)))
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(109, 109, 109)
                                .addComponent(jLabel21)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 22, Short.MAX_VALUE)
                                .addComponent(txt_add_price, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                        .addComponent(jLabel20)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                        .addComponent(jLabel22)
                                        .addGap(18, 18, 18)
                                        .addComponent(txt_add_quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addGap(105, 105, 105))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txt_add_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txt_add_title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txt_add_author, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(txt_add_publisher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_add_publication_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(79, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(txt_add_price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(txt_add_quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_add_product)
                    .addComponent(btn_ctr_add_clear))
                .addGap(27, 27, 27))
        );

        tabbed_product.addTab("Add Product", jPanel7);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel23.setText("Book ID");

        txt_edit_id.setBackground(new java.awt.Color(242, 242, 242));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel24.setText("Title");

        txt_edit_title.setBackground(new java.awt.Color(242, 242, 242));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel25.setText("Author(s)");

        txt_edit_author.setBackground(new java.awt.Color(242, 242, 242));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel26.setText("Publisher");

        txt_edit_publisher.setBackground(new java.awt.Color(242, 242, 242));

        jLabel27.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel27.setText("Publication Date");

        txt_edit_publication_date.setBackground(new java.awt.Color(242, 242, 242));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel28.setText("Price");

        jLabel29.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel29.setText("Quantity in Stock");

        txt_edit_price.setBackground(new java.awt.Color(242, 242, 242));

        txt_edit_quantity.setBackground(new java.awt.Color(242, 242, 242));

        btn_edit_search.setBackground(new java.awt.Color(242, 242, 242));
        btn_edit_search.setText("Search");
        btn_edit_search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_edit_searchMouseClicked(evt);
            }
        });

        btn_edit_product.setBackground(new java.awt.Color(242, 242, 242));
        btn_edit_product.setText("Edit Product");
        btn_edit_product.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_edit_productMouseClicked(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel30.setText("Description");

        txt_edit_descript.setBackground(new java.awt.Color(242, 242, 242));
        txt_edit_descript.setColumns(20);
        txt_edit_descript.setRows(5);
        jScrollPane3.setViewportView(txt_edit_descript);

        btn_ctr_edit_clear.setBackground(new java.awt.Color(242, 242, 242));
        btn_ctr_edit_clear.setText("Clear");
        btn_ctr_edit_clear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_ctr_edit_clearMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel27)
                    .addComponent(jLabel23)
                    .addComponent(jLabel24)
                    .addComponent(jLabel25)
                    .addComponent(jLabel26))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_edit_id, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txt_edit_title, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt_edit_publication_date, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt_edit_publisher, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txt_edit_author, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addComponent(btn_ctr_edit_clear)
                            .addGap(12, 12, 12)
                            .addComponent(btn_edit_product))
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel29, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel30, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txt_edit_price)
                                .addComponent(txt_edit_quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                    .addComponent(btn_edit_search))
                .addGap(116, 116, 116))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(txt_edit_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_edit_search))
                .addGap(17, 17, 17)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(txt_edit_title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(txt_edit_author, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(txt_edit_publisher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(txt_edit_publication_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28)
                            .addComponent(txt_edit_price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel29)
                            .addComponent(txt_edit_quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel30)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_edit_product)
                    .addComponent(btn_ctr_edit_clear))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        tabbed_product.addTab("Edit Product", jPanel8);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        table_product.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Title", "Author(s)", "Genre", "Publisher", "Publication Date ", "Price", "Quantity in Stock "
            }
        ));
        jScrollPane1.setViewportView(table_product);

        btn_delete.setBackground(new java.awt.Color(242, 242, 242));
        btn_delete.setText("Delete");
        btn_delete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_deleteMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 695, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_delete)))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_delete)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        tabbed_product.addTab("Product List", jPanel9);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tabbed_product)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(btn_back)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabbed_product, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_back)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_backMouseClicked

        dispose();
        Main_Frame main = new Main_Frame();
        main.setVisible(true);

    }//GEN-LAST:event_btn_backMouseClicked

    private void btn_add_productMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_add_productMouseClicked
        System.out.println("Add Product Click");
        
        String sql = "insert into Product(product_id, product_title, product_author, product_publisher,"
                            + "product_publication_date, product_price, product_quantity, product_description) values(?,?,?,?,?,?,?,?)";
                try{
            pst = conn.prepareStatement(sql);
            pst.setString(1, txt_add_id.getText());
            pst.setString(2, txt_add_title.getText());
            pst.setString(3, txt_add_author.getText());
            pst.setString(4, txt_add_publisher.getText());
            pst.setString(5, txt_add_publication_date.getText());
            pst.setString(6, txt_add_price.getText());
            pst.setString(7, txt_add_quantity.getText());
            pst.setString(8, txt_add_descript.getText());
            
            pst.execute();
            JOptionPane.showMessageDialog(null, "Add Product Successful...");
            
            txt_add_id.setText("");
            txt_add_title.setText("");
            txt_add_author.setText("");
            txt_add_publisher.setText("");
            txt_add_publication_date.setText("");
            txt_add_price.setText("");
            txt_add_quantity.setText("");
            txt_add_descript.setText("");
            
            Product_Table();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Add Product Unsuccessful... :" + e);
        }finally{
            try{
                rs.close();
                pst.close();
            }catch(Exception e){
                JOptionPane.showMessageDialog(null,e);
            }
        }

    }//GEN-LAST:event_btn_add_productMouseClicked

    private void btn_edit_productMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_edit_productMouseClicked
        System.out.println("Edit Product Click");
        
        try{
            String value_search = txt_edit_id.getText();
            String value_title = txt_edit_title.getText();
            String value_author = txt_edit_author.getText();
            String value_publisher = txt_edit_publisher.getText();
            String value_publication_date = txt_edit_publication_date.getText();
            String value_price =  txt_edit_price.getText();
            String value_quantity = txt_edit_quantity.getText();
            String value_descript = txt_edit_descript.getText();

            String sql = "UPDATE Product SET product_title='"+value_title
                            +"', product_author='"+value_author
                            +"', product_publisher='"+value_publisher
                            +"', product_publication_date='"+value_publication_date
                            +"', product_price='"+value_price 
                            +"',product_quantity='"+value_quantity
                            +"',product_description='"+value_descript
                            + "' where product_id='"+value_search+"'";
            
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Product updated successfully");
            
            txt_edit_id.setText("");
            txt_edit_title.setText("");
            txt_edit_author.setText("");
            txt_edit_publisher.setText("");
            txt_edit_publication_date.setText("");
            txt_edit_price.setText("");
            txt_edit_quantity.setText("");
            txt_edit_descript.setText("");
            
            Product_Table();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }finally{
            try{
                rs.close();
                pst.close();
            }catch(Exception e){
                JOptionPane.showMessageDialog(null,e);
            }
        }
        

    }//GEN-LAST:event_btn_edit_productMouseClicked

    private void btn_deleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_deleteMouseClicked
       // System.out.println("Delete Product Click");
       try{
       
            int n = JOptionPane.showConfirmDialog(
                null,
                "Delete ?",
                "Book Shopping System",
                JOptionPane.YES_NO_OPTION);

            if(n==0){
                int row = table_product.getSelectedRow();
                String cell = table_product.getModel().getValueAt(row, 0).toString();
                String sql = "DELETE FROM Product where product_id = ?";
                try{
                    pst = conn.prepareStatement(sql);
                    pst.setString(1, cell);
                    pst.execute();
                    JOptionPane.showMessageDialog(null,"Delete Successfully");

                    Product_Table();

                }catch(Exception e){
                    JOptionPane.showMessageDialog(null,"Delete Unsuccess : " + e);
                }finally{
                    try{
                        rs.close();
                        pst.close();
                    }catch(Exception e){
                        JOptionPane.showMessageDialog(null,e);
                    }
                }
            }
        
       }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Select row for Delete, please.");
       }
    }//GEN-LAST:event_btn_deleteMouseClicked

    private void btn_edit_searchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_edit_searchMouseClicked
        System.out.println("Search Product Click");

        String sql = "SELECT * FROM Product WHERE product_id = ?";
        try{
            pst = conn.prepareStatement(sql);
            pst.setString(1,txt_edit_id.getText());
            rs = pst.executeQuery();

            if(rs.next()){
                String add1 = rs.getString("product_title");
                txt_edit_title.setText(add1);

                String add2 = rs.getString("product_author");
                txt_edit_author.setText(add2);

                String add3 = rs.getString("product_publisher");
                txt_edit_publisher.setText(add3);

                String add4 = rs.getString("product_publication_date");
                txt_edit_publication_date.setText(add4);

                String add5 = rs.getString("product_price");
                txt_edit_price.setText(add5);

                String add6 = rs.getString("product_quantity");
                txt_edit_quantity.setText(add6);
                
                String add7 = rs.getString("product_description");
                txt_edit_descript.setText(add7);

                rs.close();
                pst.close();
            }else{
                JOptionPane.showMessageDialog(null,"Please enter correct Book ID");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }//GEN-LAST:event_btn_edit_searchMouseClicked

    private void btn_ctr_add_clearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_ctr_add_clearMouseClicked
        // add customer
        txt_add_id.setText("");
        txt_add_title.setText("");
        txt_add_author.setText("");
        txt_add_publisher.setText("");
        txt_add_publication_date.setText("");
        txt_add_price.setText("");
        txt_add_quantity.setText("");
        txt_add_descript.setText("");
    }//GEN-LAST:event_btn_ctr_add_clearMouseClicked

    private void btn_ctr_edit_clearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_ctr_edit_clearMouseClicked
        //edit customer
        txt_edit_id.setText("");
        txt_edit_title.setText("");
        txt_edit_author.setText("");
        txt_edit_publisher.setText("");
        txt_edit_publication_date.setText("");
        txt_edit_price.setText("");
        txt_edit_quantity.setText("");
        txt_edit_descript.setText("");
    }//GEN-LAST:event_btn_ctr_edit_clearMouseClicked


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Product_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Product_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Product_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Product_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Product_Frame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add_product;
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_ctr_add_clear;
    private javax.swing.JButton btn_ctr_edit_clear;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_edit_product;
    private javax.swing.JButton btn_edit_search;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane tabbed_product;
    private javax.swing.JTable table_product;
    private javax.swing.JTextField txt_add_author;
    private javax.swing.JTextArea txt_add_descript;
    private javax.swing.JTextField txt_add_id;
    private javax.swing.JTextField txt_add_price;
    private javax.swing.JTextField txt_add_publication_date;
    private javax.swing.JTextField txt_add_publisher;
    private javax.swing.JTextField txt_add_quantity;
    private javax.swing.JTextField txt_add_title;
    private javax.swing.JTextField txt_edit_author;
    private javax.swing.JTextArea txt_edit_descript;
    private javax.swing.JTextField txt_edit_id;
    private javax.swing.JTextField txt_edit_price;
    private javax.swing.JTextField txt_edit_publication_date;
    private javax.swing.JTextField txt_edit_publisher;
    private javax.swing.JTextField txt_edit_quantity;
    private javax.swing.JTextField txt_edit_title;
    // End of variables declaration//GEN-END:variables
}
